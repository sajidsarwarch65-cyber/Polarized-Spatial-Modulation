function [lut, polarization_table] = BPSM_Look_Up_Table(N, M, p)
    % N: Number of antennas
    % M: Modulation order
    % p: Power levels for each antenna
    
    % Validate input length of p
    if length(p) ~= N
        error('The size of vector p must be equal to N.');
    end
    
    % Calculate the number of polarization patterns: 2^N
    num_patterns = 2^N;
    
    % Generate binary representation of all patterns
    polarization_patterns = de2bi(0:num_patterns-1, N, 'left-msb'); % Binary patterns
    
    % Generate the symbols for M-ary PSK modulation
    symbols = pskmod(0:M-1, M); % Create M-PSK symbols (e.g., BPSK: 1, -1)
    
    % Initialize lookup table
    lut = []; % This will store the combined symbol representations
    polarization_table = polarization_patterns; % Store the polarization patterns
    
    % Generate all combinations of M symbols for N antennas using ndgrid
    symbol_grid = cell(1, N); % Preallocate cell array for grid generation
    [symbol_grid{:}] = ndgrid(symbols); % Create a grid of all combinations
    combinations = reshape(cat(N+1, symbol_grid{:}), [], N); % Reshape to obtain all possible combinations
    
    % Calculate the total number of combinations: M^N
    num_combinations = size(combinations, 1);
    
    % Iterate over all polarization patterns
    for i_Polar = 1:size(polarization_patterns, 1)
        current_pattern = polarization_patterns(i_Polar, :); % Get the current polarization pattern
        
        % For each polarization pattern, combine with all symbol combinations
        for i_Comb = 1:num_combinations
            % Initialize temp array for storing polarized symbols
            temp = zeros(2 * N, 1); % Each antenna's symbol will be a 2-element vector (H or V)
            
            % Assign symbols based on polarization state and scale by power levels
            for ant = 1:N
                power_level = p(ant); % Assign the power level corresponding to this antenna
                if current_pattern(ant) == 0 % Horizontal polarization (0 -> H)
                    temp(2 * ant - 1) = power_level * combinations(i_Comb, ant); % H is active
                else % Vertical polarization (1 -> V)
                    temp(2 * ant) = power_level * combinations(i_Comb, ant); % V is active
                end
            end
            
            % Append the results to the lookup table
            lut = [lut, temp];
        end
    end

    % Display the resulting lookup table
    disp('Final Lookup Table with Distinct Power Levels Applied:');
    disp(lut);
end
