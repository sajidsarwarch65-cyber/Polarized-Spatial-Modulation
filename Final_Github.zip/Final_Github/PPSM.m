%% ============================================================
% Unified PPSM BER Simulation (4x4 or 8x8, On-the-Fly LUT)
% =============================================================
% - 4x4 Dual-Polarization (H/V) PPSM
% - 8x8 Quad-Polarization (H/V/RHCP/LHCP) PPSM
% - Select configuration by setting T = 4 or T = 8
% =============================================================
clear; clc; close all;

%% -------------------- Simulation Parameters --------------------
T = 4;                % # of transmit antennas: choose 4 or 8
Nr = T;               % # of receive antennas
M = 2;                % Modulation order (BPSK)
SNR_dB = -10:4:10;    % SNR range
NumIter = 200;        % Monte Carlo iterations
fprintf('--- PPSM Monte-Carlo Simulation ---\n');

%% -------------------- Case Configuration --------------------
switch T
    case 4
        fprintf('Config: 4x4 Dual-Polarization (H/V)\n');
        pol_str = {'H','V'};
        numPol = numel(pol_str);
        numPatterns = 2^T;     % 16 polarization patterns (unique H/V)
        b1 = log2(numPatterns);% index bits
        modeLabel = 'Dual-Pol';
    case 8
        fprintf('Config: 8x8 Quad-Polarization (H/V/RHCP/LHCP)\n');
        pol_str = {'H','V','RHCP','LHCP'};
        numPol = numel(pol_str);
        b1 = floor(log2(factorial(8)));               % # index bits → 2^15 = 32768 patterns
        numPatterns = 2^b1;
        modeLabel = 'Quad-Pol';
    otherwise
        error('Only T=4 or T=8 supported.');
end

NtPorts = 4*T;
NrPorts = 4*Nr;

%% -------------------- Symbol Combination LUT --------------------
symbols = pskmod(0:M-1, M);           % BPSK symbols
[symGrid{1:T}] = ndgrid(symbols);
symComb = reshape(cat(T+1, symGrid{:}), [], T);  % M^T x T

%% -------------------- Polarization Pattern Table --------------------
fprintf('Generating %d polarization patterns...\n', numPatterns);
allPatterns = zeros(numPatterns, T);

if T == 4
    % Binary patterns for dual-pol H/V
    allPatterns = dec2bin(0:numPatterns-1) - '0' + 1;  % 16 x 4
else
    % Base-4 patterns for quad-pol
    for k = 0:numPatterns-1
        tmp = dec2base(k, numPol, T) - '0' + 1;  % convert to base-4 digits
        allPatterns(k+1,:) = tmp;
    end
end

%% -------------------- Main Monte-Carlo Loop --------------------
ABER = zeros(size(SNR_dB));
fprintf('Total patterns = %d, symbol combos = %d\n', numPatterns, size(symComb,1));

for s = 1:length(SNR_dB)
    sigma_n = 1 / 10^(SNR_dB(s)/10);
    err_bits = 0;

    for itr = 1:NumIter
        % ----- Random transmit combination -----
        idxPol = randi([1 numPatterns]);
        idxSym = randi([1 size(symComb,1)]);
        polPat = allPatterns(idxPol,:);
        symVec = symComb(idxSym,:);

        % ----- Build transmit vector on-the-fly -----
        x = zeros(NtPorts,1);
        for ant = 1:T
            s_val = symVec(ant);
            switch polPat(ant)
                case 1, x(4*ant-3) = s_val; % H
                case 2, x(4*ant-2) = s_val; % V
                case 3, x(4*ant-1) = s_val; % RHCP
                case 4, x(4*ant)   = s_val; % LHCP
            end
        end

        % ----- Channel + Noise -----
        H = (randn(NrPorts, NtPorts) + 1j*randn(NrPorts, NtPorts)) / sqrt(2);
        n = sqrt(sigma_n)*(randn(NrPorts,1)+1j*randn(NrPorts,1))/sqrt(2);
        y = H*x + n;

        % ----- ML Detection (Exhaustive, On-the-Fly) -----
        minDist = inf;
        idx_hatPol = 0; idx_hatSym = 0;
        for ip = 1:numPatterns
            pat = allPatterns(ip,:);
            for ic = 1:size(symComb,1)
                vec = zeros(NtPorts,1);
                for ant = 1:T
                    s_val = symComb(ic,ant);
                    switch pat(ant)
                        case 1, vec(4*ant-3) = s_val;
                        case 2, vec(4*ant-2) = s_val;
                        case 3, vec(4*ant-1) = s_val;
                        case 4, vec(4*ant)   = s_val;
                    end
                end
                dist = sum(abs(y - H*vec).^2);
                if dist < minDist
                    minDist = dist;
                    idx_hatPol = ip;
                    idx_hatSym = ic;
                end
            end
        end

        % ----- Bit Error Counting -----
        tx_bits = [dec2bin(idxPol-1,b1)-'0', dec2bin(idxSym-1,T*log2(M))-'0'];
        rx_bits = [dec2bin(idx_hatPol-1,b1)-'0', dec2bin(idx_hatSym-1,T*log2(M))-'0'];
        err_bits = err_bits + sum(tx_bits ~= rx_bits);
    end

    total_bits = NumIter * (b1 + T*log2(M));
    ABER(s) = err_bits / total_bits;
    fprintf('SNR=%3.1f dB -> ABER=%.4e\n', SNR_dB(s), ABER(s));
end

%% -------------------- Plot Results --------------------
figure;
semilogy(SNR_dB, ABER, '-o', 'LineWidth', 1.5); grid on;
xlabel('SNR (dB)');
ylabel('Average Bit Error Rate (ABER)');
title(sprintf('%dx%d PPSM BER (%s, On-the-Fly ML)', T, Nr, modeLabel));
