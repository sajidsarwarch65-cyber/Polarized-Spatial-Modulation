function I = BPSM_MI(varargin)
% BPSM_SMT  Simulated Mutual Information for BPSM (Dual/Quad Polarized SMT)
%%I = BPSM_MI( 'bpsm' ,M, Nt ,Nr , Ch_Err , SNR_Vector , NumItr )
% %SMT_SyS='bpsm'; M=4; Nt=4; Nr=4; Ch_Err=false;  SNR_Vector=-10:2:10;  NumItr=10000; 
% Usage Example:
%   I = BPSM_SMT('bpsm', 4, 4, 4, false, -10:2:10, 1e4);
%
% Inputs:
%   SMT_SyS     : 'bpsm'
%   M           : Modulation order (e.g., 2, 4, 8)
%   Nt          : No. of transmit antennas (physical)
%   Nr          : No. of receive antennas (physical)
%   Ch_Err      : Channel estimation error flag or value
%   SNR_Vector  : Vector of SNR values (in dB)
%   NumItr      : Number of Monte Carlo iterations
%
% Output:
%   I           : Estimated mutual information

%% --- Parse Inputs ---
switch nargin
    case 7  % Rayleigh case
        SMT_SyS = lower(varargin{1});
        M = varargin{2};
        Nt = varargin{3};
        Nr = varargin{4};
        Ch_Type = 'rayleigh';
        Ch_Err = varargin{5};
        SNR_Vector = varargin{6};
        NumItr = varargin{7};
    otherwise
        error('Incorrect number of input arguments.');
end

%% --- Adjust Antenna Dimensions for Dual Polarization ---
% Since the channel model is uni-polar, double the effective antenna count
Nt_eff = 2 * Nt;   % Effective transmit dimension
Nr_eff = 2 * Nr;   % Effective receive dimension

fprintf('Dual-Polarization BPSM: Using effective channel size %dx%d\n', Nr_eff, Nt_eff);

%% --- Generate Constellation LUT ---
SMT_CD = BPSM_Look_Up_Table(Nt, M);  % LUT generated for physical Nt (internally handles polarization)
eta = log2(size(SMT_CD, 2));         % Spectral efficiency

%% --- Simulation Initialization ---
I = zeros(size(SNR_Vector));
sig_n = 1 ./ 10.^(SNR_Vector / 10);  % Noise variance

% Channel Estimation Error (CSE)
if islogical(Ch_Err)
    if Ch_Err
        sig_e = sig_n;               % sigma_e = sigma_n
    else
        sig_e = zeros(size(sig_n));  % No CSE
    end
elseif length(Ch_Err) == 1
    sig_e = Ch_Err * ones(size(sig_n));
elseif length(Ch_Err) == length(SNR_Vector)
    sig_e = Ch_Err;
else
    error('sigma_e and SNR_Vector must have the same length.');
end

%% --- Monte Carlo Simulation ---
for snr_idx = 1:length(SNR_Vector)
    for itr = 1:NumItr
        % Random data index
        data_idx = randi([0, 2^eta - 1]);

        % BPSM modulation
        xt = SMT_CD(:, data_idx + 1);

        % Generate channel (Rayleigh)
        H_CSE = (randn(Nr_eff, Nt_eff) + 1j * randn(Nr_eff, Nt_eff)) / sqrt(2);

        % Channel estimation error
        e = sqrt(sig_e(snr_idx)) * (randn(Nr_eff, Nt_eff) + 1j * randn(Nr_eff, Nt_eff)) / sqrt(2);
        H = H_CSE + e;

        % Additive noise
        noise = sqrt(sig_n(snr_idx)) * (randn(Nr_eff, 1) + 1j * randn(Nr_eff, 1)) / sqrt(2);

        % Received signal
        y = H * xt + noise;

        % Compute mutual information
        sg_y = (sig_n(snr_idx) + sig_e(snr_idx) * sum(abs(SMT_CD).^2));
        EucDis = sum(abs(repmat(y, 1, 2^eta) - H_CSE * SMT_CD).^2, 1);
        I(snr_idx) = I(snr_idx) ...
            - log2(mean(exp(-EucDis ./ sg_y) ./ sg_y.^Nr_eff)) ...
            - mean(Nr_eff * log2(sg_y .* exp(1)));
    end
end

I = I / NumItr;

fprintf('Simulation complete for %d iterations per SNR.\n', NumItr);
end
