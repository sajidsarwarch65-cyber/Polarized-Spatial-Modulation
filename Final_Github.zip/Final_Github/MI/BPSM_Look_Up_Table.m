function [lut, polarization_table] = BPSM_Look_Up_Table(N, M)
    % BPSM_Look_Up_Table: Generates lookup table for BPSM modulation
    % N: Number of antennas
    % M: Modulation order

    % Calculate number of polarization patterns: 2^N
    num_patterns = 2^N;

    % Generate binary representation of all polarization patterns
    polarization_patterns = de2bi(0:num_patterns-1, N, 'left-msb'); % Binary patterns (0=H, 1=V)

    % Generate M-ary PSK symbols
    symbols = pskmod(0:M-1, M); % e.g., for BPSK -> [1, -1]

    % Initialize lookup table
    lut = [];
    polarization_table = polarization_patterns;

    % Generate all combinations of M symbols for N antennas using ndgrid
    symbol_grid = cell(1, N);
    [symbol_grid{:}] = ndgrid(symbols);
    combinations = reshape(cat(N+1, symbol_grid{:}), [], N); % All possible symbol combinations
    num_combinations = size(combinations, 1);

    % Iterate over all polarization patterns
    for i_Polar = 1:size(polarization_patterns, 1)
        current_pattern = polarization_patterns(i_Polar, :);

        % For each pattern, combine with all symbol combinations
        for i_Comb = 1:num_combinations
            temp = zeros(2 * N, 1); % H/V entries per antenna

            % Assign symbols based on polarization state
            for ant = 1:N
                if current_pattern(ant) == 0 % Horizontal polarization (H)
                    temp(2 * ant - 1) = combinations(i_Comb, ant);
                else % Vertical polarization (V)
                    temp(2 * ant) = combinations(i_Comb, ant);
                end
            end

            % Append to lookup table
            lut = [lut, temp];
        end
    end

    % Display lookup table summary
    disp('Final BPSM Lookup Table:');
    disp(lut);
end
