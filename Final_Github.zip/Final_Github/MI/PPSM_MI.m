% function I = BPSM_SMT( varargin )
% %I = BPSM_SMT( SMT_SyS ,M, Nt ,Nr , Ch_Err , SNR_Vector , NumItr )
% %SMT_SyS='PSM'; M=4; Nt=4; Nr=4; Ch_Err=false;  SNR_Vector=-10:2:10;  NumItr=10000; 
% %Recommended SNR for Quad polarization: SNR_Vector=-10:2:30;
% % ====================================================================
% 
% % ====================================================================
% %
% % De s c r i p t i o n
% % This s c r i p t c a l c u l a t e s the simulated mutual informat ion of space
% % modulation techniques (SMTs) over g ene r a l i z ed f ading channel and in
% % the presence of channel es t imat ion error s (CSEs )
% %%
% %
% %
% % M Size of the s i g n a l c o n s t e l l a t i o n diagram .
% % Note , for SSK the value of M does not matter .
% %
% % Nt For SMTs : Nt i s a single element ind i c a t ing the
% % number of t ransmi t antennas .
% % For GSMTs and GQSMTs: Nt i s a two element vector :
% % - The f i r s t element , Nt ( 1 ) , i s the number of
% % t ransmi t antennas ;
% % - The second element , Nt ( 2 ) , i s the number of
% % a c t i v e t ransmi t antennas at a time ( nu )
% %
% % Nr Number of r e c e i v e antennas .
% %
% % Ch_Type A s t r ing i n d i c a t i n g the type of channel to
% % ca l c u l a t e the ABER over :
% % -'rayl e igh'or'ray'for Rayleigh ;
% % -'rician'or'r ice'f o r Rician ;
% % -'nakagami'or'nak'for Nakagami .
% % K Rician K f a c tor in dB .
% % m Shape parameter of the Nakagami-m f ading channel .
% %
% % Ch_Err - L o g i c a l Fa l s e f o r no CSE .
% 
% % - L o g i c a l True for CSE and sigma_e = sigma_n .
% % - a s ing l e double containing sigma_e .
% % - a vector containing a v a r i a b l e sigma_e .
% % Note , the vector has to have the same length as
% % the range of the SNR def ined next .
% %
% % SNR_Vector Vector cont a ining the s i gna l -to-noise r a t i o (SNR)
% % v a lue s to c a l c u l a t e the ABER over .
% %
% % NumItr Number of simulation i t e r a t i o n s .
% %
% % Output
% % I The simulated mutual information .
% %
% % Usage
% %
% % For Rayleigh
% % I = I_SMT( SMT_SyS ,M, Nt ,Nr , Ch_Err , SNR_Vector , NumItr )
% %%
% % For Rician with K f a c tor
% % I = I_SMT( SMT_SyS ,M, Nt ,Nr , Ch_Type ,K, Ch_Err , SNR_Vector , NumItr )
% %%
% % For Nakagami-m with m shaping parameter
% % I = I_SMT( SMT_SyS ,M, Nt ,Nr , Ch_Type ,m, Ch_Err , SNR_Vector , NumItr )
% %% Defining input parameters
% switch nargin
%     case 7 % Rayleigh fading
%         SMT_SyS = lower ( varargin { 1 } ) ;
%         M = varargin {2} ;
%         Nt = varargin {3} ;
%         if ~strcmp ( SMT_SyS ( 1 ) ,'g') && length (Nt) >1
%             error ('For SMTs Nt should be a single element')
%         end
%         Nr = varargin {4} ;
%         Ch_Type ='rayleigh';
%         Ch_Err = varargin {5} ;
%         SNR_Vector = varargin { 6 } ;
%         NumItr = varargin {7} ;
%     case 8 % Rayleigh fading
%         SMT_SyS = lower ( varargin { 1 } ) ;
%         M = varargin {2} ;
%         Nt = varargin {3} ;
%         if ~strcmp ( SMT_SyS ( 1 ) ,'g') && length (Nt) >1
%             error ('For SMTs Nt should be a single element')
%         end
%         Nr = varargin {4} ;
%         Ch_Type = lower ( varargin { 5 } ) ;
%         if ~strcmp ( Ch_Type ,'rayleigh') || ~strcmp (Ch_Type ,'ray')
%             error ('Unknown Channel or mi s s ing channel parameter')
%         end
%         Ch_Err = varargin {6} ;
%         SNR_Vector = varargin { 7 } ;
%         NumItr = varargin {8} ;
%     case 9 % Rician or Nakagami-m
%         SMT_SyS = lower ( varargin { 1 } ) ;
%         M = varargin {2} ;
%         Nt = varargin {3} ;
%         if ~strcmp ( SMT_SyS ( 1 ) ,'g') && length (Nt) >1
%             error ('For SMTs Nt should be a single element')
%         end
%         Nr = varargin {4} ;
%         Ch_Type = lower ( varargin { 5 } ) ;
%         if strcmp (Ch_Type ,'rician') || strcmp ( Ch_Type ,'rice')
%             KdB = varargin {6} ;
%             K = 10^(KdB/10) ;
%         elseif strcmp (Ch_Type ,'nak') || strcmp (Ch_Type ,'nakagami')
%             m = varargin {6} ;
%         else
%             error ('Unknown Channel')
%         end
%         Ch_Err = varargin {7} ;
%         SNR_Vector = varargin { 8 } ;
%         NumItr = varargin {9} ;
%     otherwise
%         error ('Not enough or too many inputs')
% end
% 
% %% Generating the SMT c o n s t e l l a t i o n matrix
% 
% p=ones(1,8); %Proposed PPSM. To meet this dimensions, Nt=32, Nr=32--> equivalent to 4 by 4 PPSM (Quad polarization)
% [lut, polarization_table] =generalized_LUT_with_Quad_Polarization(Nt/4, M, p); % for 8 antennas perm-PSM
% SMT_CD=lut; %generalized_LUT_with_Dual_Polarization(Nt/2, M, p);
% 
% % The spe c t r a l e f f i c i e n c y
% eta = log2 ( size (SMT_CD, 2 ) ) ;
% % In ca se of GSMTs Nu i s not needed anymore
% Nt = Nt ( 1 ) ;
% %% Simulat ion to c a l c u l a t e the Mutual Informat ion
% % Pr e a l l o c a t e v a r i a b l e s to s tore the c a l c u l a t e d ABER
% I = zeros ( size ( SNR_Vector ) ) ;
% % The range of the noise variance
% sig_n = 1./ 10.^(SNR_Vector / 10 ) ;
% % CSE
% if islogical (Ch_Err )
%     if Ch_Err % CSE with sigma_e = sigma_n
%         sig_e = sig_n ;
%     else% no CSE
%         sig_e = zeros ( size ( sig_n ) ) ;
%     end
% elseif length ( Ch_Err )==1 % CSE with constant sigma_e
%     sig_e = Ch_Err* ones ( size ( sig_n ) ) ;
% else% CSE with sigma_e given as a matrix
%     if length ( Ch_Err ) == length ( SNR_Vector )
%         sig_e = Ch_Err ;
%     else
%         error ('sigma_e and SNR_Vector has to be the same l ength')
%     end
% end
% for snr = 1 : length ( SNR_Vector )
%     for itr = 1 : NumItr
%         % Generate the data symbol to be t r ansmi t t ed
%         PreGenData = randi ( [ 0 (2^ eta - 1 ) ] ) ;
%         % SMT modulation
%         xt = SMT_CD( : , PreGenData +1) ;
%         % Pas s ing through channel
%         switch Ch_Type
%             case {'ray','rayleigh'}
%                 H_CSE = ( randn (Nr , Nt ) + 1j.* randn (Nr , Nt ) ) / sqrt ( 2 ) ;
%             case {'rice','rician'}
%                 H_CSE = ( randn (Nr , Nt ) + 1j.* randn (Nr , Nt ) ) / sqrt ( 2 ) ;
%                 H_CSE = sqrt (K/(1+K) )* ones ( size (H_CSE) ) + sqrt (1/(1+K) )*H_CSE ;
% 
%             case {'nak','nakagami'}
%                 H_CSE = sqrt ( sum( abs ( randn (Nr ,Nt ,m) / sqrt (2*m) ) .^ 2 , 3 ) ) +1j.* sqrt ( sum( abs ( randn (Nr ,Nt ,m) / sqrt (2*m) ) .^ 2 , 3 ) ) ;
%         end
%         % Generating CSE noi se
%         % Note , for no CSE sigma_e =0 , and consequently , e wi l l be an
%         % Nr*Nt square matrix
%         e = sqrt(sig_e(snr))* ( randn (Nr , Nt )+1j*randn (Nr ,Nt ) ) / sqrt ( 2 ) ;
%         % Channel without CSE
%         % Note , in the case of no CSE , e i s an a l l zeros matrix .
%         % Hence , H = H_CSE
%         H =H_CSE+e ;
%         % Generating the noi se
%         noise = sqrt ( sig_n(snr))* (randn(Nr ,1)+1j*randn (Nr , 1 ) ) / (sqrt ( 2 )*1) ;
%         % The received s i g n a l
%         y =H* xt + noise ;
%         % Ca l c u l a t i n g the Mutual Informat ion
%         sg_y = ( sig_n( snr )+ sig_e(snr)*sum( abs(SMT_CD).^2 ) ) ;
%         EucDis = sum( abs( repmat( y ,1 ,2^eta )-H_CSE*SMT_CD).^2 , 1 ) ;
%         I ( snr ) = I( snr ) -log2(mean( exp(-EucDis./ sg_y )./ sg_y.^Nr ) ) - mean (Nr* log2( sg_y.* exp( 1 ) ) ) ;
%     end
% end
% I = I / NumItr ;
% end



function I = PPSM_MI(varargin)
% I = PPSM_SMT(SMT_SyS, M, Nt, Nr, Ch_Err, SNR_Vector, NumItr)
% ========================================================================
% Description:
%   Calculates the simulated mutual information (MI) for Polarized
%   Spatial Modulation Techniques (PPSM / Quad-Polarization PSM)
%   over generalized fading channels with optional channel estimation errors.
%
% Example:
%   SMT_SyS = 'ppsm';
%   M = 2; Nt = 8; Nr = 8; 
%   Ch_Err = false;
%   SNR_Vector = -10:2:30;
%   NumItr = 10000; % reduce number of iterations to see output quickly
%   I = PPSM_SMT(SMT_SyS, M, Nt, Nr, Ch_Err, SNR_Vector, NumItr);
% ========================================================================

%% Parse Inputs
switch nargin
    case 7
        SMT_SyS = lower(varargin{1});
        M = varargin{2};
        Nt = varargin{3};
        Nr = varargin{4};
        Ch_Type = 'rayleigh';
        Ch_Err = varargin{5};
        SNR_Vector = varargin{6};
        NumItr = varargin{7};
    case 9
        SMT_SyS = lower(varargin{1});
        M = varargin{2};
        Nt = varargin{3};
        Nr = varargin{4};
        Ch_Type = lower(varargin{5});
        param = varargin{6}; % K or m
        Ch_Err = varargin{7};
        SNR_Vector = varargin{8};
        NumItr = varargin{9};
    otherwise
        error('Incorrect number of input arguments.');
end

%% Adjust Dimensions for Quad Polarization
% Each antenna has 4 polarization components (H, V, RHCP, LHCP)
Nt_eff = 4 * Nt;
Nr_eff = 4 * Nr;

fprintf('Quad-polarized system: %dx%d equivalent to unipolar %dx%d\n', ...
    Nt, Nr, Nt_eff, Nr_eff);

%% Generate LUT for Quad Polarized PPSM
[lut, polarization_table] = PPSM_QP_Look_Up_Table(Nt, M);
SMT_CD = lut; % Symbol + polarization combinations

% Spectral Efficiency
eta = log2(size(SMT_CD, 2));

%% Simulation for Mutual Information (MI)
I = zeros(size(SNR_Vector));
sig_n = 1 ./ 10.^(SNR_Vector / 10);

% Handle Channel Estimation Error (CSE)
if islogical(Ch_Err)
    if Ch_Err
        sig_e = sig_n; % sigma_e = sigma_n
    else
        sig_e = zeros(size(sig_n));
    end
elseif isscalar(Ch_Err)
    sig_e = Ch_Err * ones(size(sig_n));
elseif numel(Ch_Err) == numel(SNR_Vector)
    sig_e = Ch_Err;
else
    error('sigma_e must be scalar, logical, or same length as SNR_Vector.');
end

%% Main Monte Carlo Loop
for snr = 1:length(SNR_Vector)
    for itr = 1:NumItr
        % Generate random data symbol
        PreGenData = randi([0, (2^eta - 1)]);

        % Modulate using LUT
        xt = SMT_CD(:, PreGenData + 1);

        % Generate Channel Matrix
        switch Ch_Type
            case {'rayleigh', 'ray'}
                H_CSE = (randn(Nr_eff, Nt_eff) + 1j * randn(Nr_eff, Nt_eff)) / sqrt(2);
            case {'rice', 'rician'}
                K = 10^(param / 10);
                H_rand = (randn(Nr_eff, Nt_eff) + 1j * randn(Nr_eff, Nt_eff)) / sqrt(2);
                H_CSE = sqrt(K / (1 + K)) * ones(Nr_eff, Nt_eff) + sqrt(1 / (1 + K)) * H_rand;
            case {'nak', 'nakagami'}
                m = param;
                H_CSE = sqrt(sum(abs(randn(Nr_eff, Nt_eff, m) / sqrt(2 * m)).^2, 3)) ...
                    + 1j * sqrt(sum(abs(randn(Nr_eff, Nt_eff, m) / sqrt(2 * m)).^2, 3));
            otherwise
                error('Unknown channel type.');
        end

        % Add Channel Estimation Error
        e = sqrt(sig_e(snr)) * (randn(Nr_eff, Nt_eff) + 1j * randn(Nr_eff, Nt_eff)) / sqrt(2);
        H = H_CSE + e;

        % AWGN
        noise = sqrt(sig_n(snr)) * (randn(Nr_eff, 1) + 1j * randn(Nr_eff, 1)) / sqrt(2);

        % Received Signal
        y = H * xt + noise;

        % Mutual Information Computation
        sg_y = sig_n(snr) + sig_e(snr) * sum(abs(SMT_CD).^2);
        EucDis = sum(abs(repmat(y, 1, 2^eta) - H_CSE * SMT_CD).^2, 1);
        I(snr) = I(snr) ...
            - log2(mean(exp(-EucDis ./ sg_y) ./ sg_y.^Nr_eff)) ...
            - mean(Nr_eff * log2(sg_y .* exp(1)));
    end
end

I = I / NumItr;
I=sort(I);
end

