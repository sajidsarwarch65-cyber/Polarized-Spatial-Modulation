function [lut, polarization_table] = PPSM_QP_Look_Up_Table(N, M)
% GENERALIZED_LUT_WITH_QUAD_POLARIZATION
% Generates a lookup table (LUT) for a Quad-Polarized M-ary modulation scheme.
%
% Inputs:
%   N  - Number of transmit antennas
%   M  - Modulation order (e.g., 2 for BPSK, 4 for QPSK)
%
% Outputs:
%   lut                - Lookup table combining polarization and modulation
%   polarization_table - Corresponding polarization pattern table
%
% Example:
%   [lut, polarization_table] = generalized_LUT_with_Quad_Polarization(8, 2);

    % Generate the symbols for M-ary PSK modulation
    symbols = pskmod(0:M-1, M); % M-PSK symbols (unit power)

    % Define polarization states
    polarization_states = {'H', 'V', 'RHCP', 'LHCP'}; 

    % Generate permutations of antenna indices
    perms_indices = perms(1:N); 
    num_perms = factorial(N);
    selected_perms_count = 2^floor(log2(num_perms)); % Nearest power of 2
    selected_perms = perms_indices(1:selected_perms_count, :);

    % Generate polarization patterns
    polarization_patterns = cell(selected_perms_count, N);
    for i = 1:selected_perms_count
        polarization_patterns(i, :) = ...
            polarization_states(mod(selected_perms(i, :) - 1, numel(polarization_states)) + 1);
    end

    % Initialize lookup table
    lut = [];
    polarization_table = polarization_patterns;

    % Generate all M^N symbol combinations using ndgrid
    symbol_grid = cell(1, N);
    [symbol_grid{:}] = ndgrid(symbols);
    combinations = reshape(cat(N+1, symbol_grid{:}), [], N);

    % Fill lookup table
    for i_Polar = 1:size(polarization_patterns, 1)
        current_pattern = polarization_patterns(i_Polar, :);
        for i_Comb = 1:size(combinations, 1)
            temp = zeros(4 * N, 1); % Four polarization dimensions per antenna

            for ant = 1:N
                symbol = combinations(i_Comb, ant); % Unit power symbol
                switch current_pattern{ant}
                    case 'H'
                        temp(4 * ant - 3) = symbol;
                    case 'V'
                        temp(4 * ant - 2) = symbol;
                    case 'RHCP'
                        temp(4 * ant - 1) = symbol;
                    case 'LHCP'
                        temp(4 * ant) = symbol;
                end
            end
            lut = [lut, temp];
        end
    end

    % Display the resulting LUT information
    fprintf('Final Lookup Table with Quad Polarization (M=%d, N=%d):\n', M, N);
    disp(['LUT Size: ', num2str(size(lut))]);
    disp('Polarization Table:');
    disp(polarization_table);
end
