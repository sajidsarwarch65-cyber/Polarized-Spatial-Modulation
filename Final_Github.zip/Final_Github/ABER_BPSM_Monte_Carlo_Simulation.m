function ABER_Sim = ABER_BPSM_Monte_Carlo_Simulation(varargin)
%run code
% SMT_SyS='PSM'; M=4;Nt=[4,4];Nr=4;;Ch_Err=0;SNR_Vector=[0:2:20];NumIterations=10000;
% ABER_BPSM_Monte_Carlo_Simulation(SMT_SyS,M,Nt,Nr,Ch_Err,SNR_Vector,NumIterations)



% ====================================================================
%
% Description
% This script calculates the average bit error ratio (ABER) of binary polarized 
% spatial modulation (BPSM) using Monte Carlo simulations , over
% generalized fading channel and in the presence of spatial
% correlation (SC) and channel estimation errors (CSEs).
%
% Inputs
% SMT_SyS A string indicating the SMT system to calculate
% the analytical ABER for ,
% -'PSM'for binary polarized spatial modulation (BPSM) ;

%
% Nt For BPSM : Nt is a single element indicating the
% number of transmi t antennas.
% For BPSM: Nt i s a two element vector :
% - The first element , Nt(1), is the number of
% transmit antennas ;

%
% M Size of the signal constellation diagram.

%
% Nr Number of receive antennas
%
% Ch_Type A string indicating the type of channel to
% calculate the ABER over :
% -'rayleigh'or'ray'for Rayleigh ;
% -'rician'or'rice'for Rician ;
% -'nakagami'or'nak'for Nakagami.
% K Rician K factor in dB.
% m Shape parameter of the Nakagami-m f ading channel.
%
% Ch_Err - Logical False for no CSE.
% - Logical True for CSE and sigma_e = sigma_n.
% - a single double containing sigma_e.

% - a vector containing a variable sigma_e.
% Note , the vector has to have the same length as
% the range of the SNR def ined next.
%
% SNR_Vector Vector containing the signal-to-noise ratio (SNR)
% value s to calculte the ABER over.
% R_tx The transmitter correlation matrix.
% R_rx The receiver correlation matrix.
%
% NumIterations Number of simulation iterations.
%
% Output
% ABER_Sim The calculate d ABER of the chosen SMT.
%
% Usage
%
% For Rayleigh with no Correlation
% ABER_Sim = SMT_ABER_Monte_Carlo_Simulation (SMT_SyS,M,Nt,Nr,...
% Ch_Err,SNR_Vector,NumIterations)
%
% For Rayleigh with Correlation
% ABER_Sim = SMT_ABER_Monte_Carlo_Simulation(SMT_SyS,M,Nt,Nr,...
% Ch_Err,R_tx,R_rx,SNR_Vector,NumIterations)
%
% For Rician with K f a c tor and no Cor relat ion
% ABER_Sim = SMT_ABER_Monte_Carlo_Simulation(SMT_SyS,M,Nt,Nr,...
% Ch_Type,K,Ch_Err,SNR_Vector,NumIterations)
%
% For Nakagami-m with m shaping parameter and no Cor r e l a t ion
% ABER_Sim = SMT_ABER_Monte_Carlo_Simulation ( SMT_SyS ,M, Nt ,Nr ,...
% Ch_Type ,m, Ch_Err , SNR_Vector , NumIterations )
%
% For Rician with K f a c tor and Cor relat ion
% ABER_Sim = SMT_ABER_Monte_Carlo_Simulation ( SMT_SyS ,M, Nt ,Nr ,...
% Ch_Type ,K, Ch_Err , R_tx , R_rx , SNR_Vector , NumIterations )
%
% For Nakagami-m with m shaping parameter and Cor r e l a t ion
% ABER_Sim = SMT_ABER_Monte_Carlo_Simulation ( SMT_SyS ,M, Nt ,Nr ,...
% Ch_Type ,m, Ch_Err , R_tx , R_rx , SNR_Vector , NumIterations )
%% Defining input parameters
try
    load(['result-',SMT_Sys,'-',num2str(L_ex)]);
    awal_snr=snr;
    awal_it=itr;
catch
    awal_snr=1;
    awal_it=1;
end
switch nargin
    case 7 % No correlation Rayleigh fading
        SMT_SyS = lower (varargin{1}) ;
        M = varargin{2} ;
        Nt = varargin{3} ;
        if ~strcmp(SMT_SyS(1),'p') && length(Nt)>1
            error('For SMTs Nt Should be a single element' )
        elseif strcmp(SMT_SyS(1),'p') && length (Nt)==1
            error('For GSMTs Nt should be a two element array')
        end
        Nr = varargin {4} ;
        Ch_Type ='rayleigh';
        Ch_Err = varargin {5} ;
        SNR_Vector = varargin{6} ;
        R_tx = eye(2*Nt(1));
        R_rx = eye(2*Nr);
        NumIterations = varargin{7} ;
    case 9 % No c o r r e l a t i o n Ri c i an or Nakagami-m
        SMT_SyS = lower ( varargin { 1 } ) ;
        M = varargin {2} ;
        Nt = varargin {3} ;
        if ~strcmp ( SMT_SyS ( 1 ) ,'p') && length (Nt) >1
            error ('For SMTs Nt soul be a single element' )
        elseif strcmp ( SMT_SyS ( 1 ) ,'p') && length (Nt)==1
            error ('For GSMTs Nt should be a two element array')
        end
        Nr = varargin {4} ;
        if ischar ( varargin { 5 } ) % for Rician or Nakagami-m
            % with no Co r r e l a t i o n
            Ch_Type = lower ( varargin { 5 } ) ;
            if strcmp (Ch_Type ,'rician') || strcmp ( Ch_Type ,'rice')
                KdB = varargin {6} ;
                K = 10^(KdB/10) ;
            elseif strcmp (Ch_Type ,'nak') || strcmp (Ch_Type ,'nakagami')
                m = varargin {6} ;
            else
                error ('Unknown Channel')
            end
            Ch_Err = varargin {7} ;
            R_tx = eye (Nt ( 1 ) ) ;
            R_rx = eye (Nr ) ;
        else % for Rayleigh with c o r r e l a t i on
            Ch_Type ='rayleigh';
            Ch_Err = varargin {5} ;
            R_tx = varargin {6} ;
            R_rx = varargin {7} ;
            
        end
        SNR_Vector = varargin {8} ;
        NumIterations = varargin {9} ;
    case 11 % for Rician or Nakagami-m with correlation
        SMT_SyS = lower ( varargin { 1 } ) ;
        M = varargin {2} ;
        Nt = varargin {3} ;
        if ~strcmp ( SMT_SyS ( 1 ) ,'p') && length (Nt) >1
            error ('For SMTs Nt soul be a single element' )
        elseif strcmp ( SMT_SyS ( 1 ) ,'p') && length (Nt)==1
            error ('For GSMTs Nt should be a two element array')
        end
        Nr = varargin {4} ;
        Ch_Type = lower ( varargin { 5 } ) ;
        if strcmp (Ch_Type ,'rician') || strcmp ( Ch_Type ,'rice')
            KdB = varargin {6} ;
            K = 10^(KdB/10) ;
        elseif strcmp (Ch_Type ,'nak') || strcmp (Ch_Type ,'nakagami')
            m = varargin {6} ;
        else
            error ('Unknown Channel')
        end
        Ch_Err = varargin {7} ;
        R_tx = varargin { 8 } ;
        R_rx = varargin {9} ;
        SNR_Vector = varargin { 10 } ;
        NumIterations = varargin {11} ;
    case 8 %kanal LIS
        L_ex=varargin {8};
        SMT_SyS = lower (varargin{1}) ;
        M = varargin{2} ;
        Nt = varargin{3} ;
        if ~strcmp(SMT_SyS(1),'p') && length(Nt)>1
            error('For SMTs Nt Should be a single element' )
        elseif strcmp(SMT_SyS(1),'p') && length (Nt)==1
            error('For GSMTs Nt should be a two element array')
        end
        Nr = varargin {4} ;
        Ch_Type ='LIS';
        Ch_Err = varargin {5} ;
        SNR_Vector = varargin{6} ;
        R_tx = eye(2*Nt(1));
        R_rx = eye(2*Nr);
        NumIterations = varargin{7} ;
    otherwise
        error ('Not enough or too many inputs')
end
%% Generating the SMT constellation matrix

Nt=Nt(1) ;
p=ones(1,Nt);



SMT_Cons_Diagram = BPSM_Look_Up_Table(Nt/1,M,p);   %proposed polar without perm (BPSM)



% The spectral efficiency

eta =floor(log2(size(SMT_Cons_Diagram,2))) ;
%% Monte Carlo ABER Simulat ion
% Pr e a l l o c a t e v a r i a b l e s to s tore the c a l c u l a t e d ABER
ABER_Sim = zeros ( size ( SNR_Vector ) ) ;
% S t a r t ing the simulation
for snr = awal_snr : length ( SNR_Vector )
    for itr = awal_it : NumIterations
        % Generate the data symbol to be t r ansmi t t ed
        PreGenData = randi([0 (2^eta-1)]);
        % SMT modulation
        xt = SMT_Cons_Diagram ( : , PreGenData +1) ;
        % Pas s ing through channel
        switch Ch_Type
            case {'ray','rayleigh'}
                H = ( randn (2*Nr , 2*Nt ) + 1j.* randn (2*Nr , 2*Nt ) ) / sqrt ( 2 ) ;
            case {'rice','rician'}
                H = ( randn (2*Nr , 2*Nt ) + 1j.* randn (Nr , 2*Nt ) ) / sqrt ( 2 ) ;
                H = sqrt (K/(1+K))* ones ( size (H) ) + sqrt (1/ (1+K) ) * H ;
            case {'nak','nakagami'}
                H = sqrt ( sum( abs ( randn (2*Nr ,2*Nt ,m) / sqrt (2*m) ).^ 2 , 3 ) )+ 1j.* sqrt ( sum( abs ( randn (Nr ,Nt ,m) / sqrt (2*m) ).^ 2 , 3 ) ) ;
            case {'LIS'}
                for iMIL=1:L_ex(1)
                    for iNR=1:Nr
                        H(iNR,iMIL)=sum((randn(L_ex(end),1)+1i*randn(L_ex(end),1))/sqrt(2),1);  % Channels between Destination and LIS
                        
                    end
                end
        end
        % Applying SC (Spatial Correlation, yang jadi identitas IM)
        % Note , for no c o r r e l a t i o n , R_tx and R_rx are a l l ones diagonal
        % matrices , and thus , H_SC = H
        H_SC = R_rx ^ ( 1 / 2 ) * H * R_tx ^ ( 1 / 2 ) ;
        % Generating the noi se
        sigma_n = 1 / 10^( SNR_Vector ( snr ) / 10 ) ;
        noise = sqrt ( sigma_n ) * ( randn (2*Nr ,1)+1j *randn (2*Nr , 1 ) ) / sqrt ( 2 ) ;
        % The received s i g n a l
        y = H_SC * xt + noise ;
        % CSE (Channel State Estimation)
        if islogical (Ch_Err )
            if Ch_Err % CSE with sigma_e = sigma_n
                sigma_e = sigma_n ;
            else % no CSE
                sigma_e = 0 ;
            end
        elseif length ( Ch_Err )==1 % CSE with constant sigma_e
            sigma_e = Ch_Err ;
            
        else % CSE with sigma_e given as a matrix
            if length ( Ch_Err ) == length ( SNR_Vector )
                sigma_e = Ch_Err ( snr ) ;
            else
                error ('sigma_e and SNR_Vector has to be the same length')
            end
        end
        % Generating CSE noi se
        % Note , for no CSE sigma_e =0 , and consequently , e wi l l be an
        % Nr*Nt square matrix
        e = sqrt (sigma_e ).* ( randn (2*Nr , 2*Nt )+1j *randn (2*Nr , 2*Nt ))./ sqrt ( 2 ) ;
        % Channel with CSE
        % Note , in the case of no CSE , e i s an a l l zeros matrix.
        % Hence , H_CSE_SC = H_SC
        H_CSE_SC = H_SC - e ;
        % Performing the ML r e c e i v e r
        SMT_ML_Bin_Res = SMT_ML_Receiver(y,H_CSE_SC,SMT_Cons_Diagram) ;
        % Ca l c u l a t i n g the BER
        BER_SMT_ML = sum( dec2bin ( PreGenData , eta )~=SMT_ML_Bin_Res ) / eta ;
        ABER_Sim ( snr ) = ABER_Sim ( snr ) + BER_SMT_ML ;
        [snr,itr]
        save(['result-',SMT_SyS,'-',Ch_Type]);
    end
end
% Averaging to get the ABER
ABER_Sim = ABER_Sim / NumIterations ;
end