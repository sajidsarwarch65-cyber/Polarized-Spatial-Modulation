function ML_Binary_Results = SMT_ML_Receiver ( y ,H, SMT_Dg)
% ====================================================================
% Book t i t l e : Space Modulation Techniques
% Authors : Raed Mesleh and Abdelhamid Alha s s i
% Pu b l i s h e r : John Wiley & Sons , Ltd
% Date : 2017
% ====================================================================
%
% De s c r i p t i o n
% This s c r i p t performs the maximum?l i k e l i h o o d (ML) r e c e i v e r to
% r e t r i e v e the transmitted binary data using space modulation
% techniques (SMTs ) .
%
% Inputs
% y The r e c e i v e d vector .
% H The fading channel matrix .
% SMT_Dg The used SMT c o n s t e l l a t i o n s diagram .
%
% Output
% ML_Binary_Results The binary data decoded by the ML r e c e i v e r .
%
% Usage
% ML_Binary_Results = SMT_ML_receiver ( y ,H, SMT_Cons_Diagram)
%% The s i z e of the used SMT c o n s t e l l a t i o n diagram
CSiz = size (SMT_Dg, 2 ) ;
%% The ML r e c e i v e r
% Ca l cul a t ing the Eucl idean di s t anc e s of a l l pos s ibl e SMT transmitted
% vector s , and then f inding the index of the SMT symbol with the
% minimum Euc l ide an di s t anc e , i . e . e r r o r .
[ ~ , Idx_min_Error ] = min ( sum( abs ( repmat ( y , 1 , CSiz )-H*SMT_Dg ).^ 2 , 1 ) ) ;
% Converting the index to binary , to r e t r i e v e the transmitted binary b i t s
ML_Binary_Results = dec2bin ( Idx_min_Error - 1 , log2(CSiz));
end