function H = generateUncorrelatedDPChannel(N, M, K, XPD)
    % N: Number of receive antennas (DP)
    % M: Number of transmit antennas (DP)
    % K: Ricean K-factor
    % XPD: Cross-Polarization Discrimination factor (in dB)
    
    % Convert XPD from dB to linear scale
    alpha = 1 / (1 + 10^(XPD / 10));
    
    % Deterministic part (LoS component) H_bar
    H_bar = sqrt([1 - alpha, alpha; alpha, 1 - alpha]);
    H_bar = kron(eye(max(N, M)), H_bar); % Create a block diagonal matrix to scale appropriately
    H_bar = H_bar(1:2*N, 1:2*M); % Adjust size to match 2N x 2M

    % Generate the random fading matrix H_tilde with i.i.d entries (2N x 2M)
    H_tilde = (randn(2*N, 2*M) + 1i * randn(2*N, 2*M)) / sqrt(2); % 2N x 2M i.i.d complex Gaussian
    
    % Combine deterministic and random parts to form H
    H = sqrt(K / (K + 1)) * H_bar + sqrt(1 / (K + 1)) * H_tilde;
end

% % Example usage:
% % Parameters
% N = 4;          % Number of receive DP antennas
% M = 4;          % Number of transmit DP antennas
% K = 5;          % Ricean K-factor
% XPD = 10;       % Cross-Polarization Discrimination in dB
% 
% % Generate the uncorrelated channel
% H = generateUncorrelatedDPChannel(N, M, K, XPD);
% 
% % Display the generated channel
% disp(H);
