function H = generateDPChannel(N, M, K, XPD, ts, rs, tp, rp)
    % N: Number of receive antennas (DP)
    % M: Number of transmit antennas (DP)
    % K: Ricean K-factor
    % XPD: Cross-Polarization Discrimination factor (in dB)
    % ts, rs: Transmit and receive spatial correlation coefficients
    % tp, rp: Transmit and receive polarization correlation coefficients
    
    % Convert XPD from dB to linear scale
    alpha = 1 / (1 + 10^(XPD / 10));
    
    % Deterministic part (LoS component) H_bar
    H_bar = sqrt([1 - alpha, alpha; alpha, 1 - alpha]);
    H_bar = kron(eye(max(N, M)), H_bar); % Create a block diagonal matrix to scale appropriately

    % Correlation matrices
    C_tp = [1, tp; conj(tp), 1];
    C_rp = [1, rp; conj(rp), 1];
    C_ts = toeplitz([1, ts, zeros(1, N-2)]); % NxN spatial correlation matrix for receive antennas
    C_rs = toeplitz([1, rs, zeros(1, M-2)]); % MxM spatial correlation matrix for transmit antennas
    
    % Combined transmit and receive correlation matrices
    C_t = kron(C_ts, C_tp); % 2M x 2M transmit correlation matrix
    C_r = kron(C_rs, C_rp); % 2N x 2N receive correlation matrix
    
    % Generate the random fading matrix H_tilde (2N x 2M matrix)
    W = (randn(2*N, 2*M) + 1i * randn(2*N, 2*M)) / sqrt(2); % Random complex Gaussian entries
    H_tilde = (C_r^(1/2)) * W * (C_t^(1/2));
    
    % Combine deterministic and random parts to form H
    H = sqrt(K / (K + 1)) * H_bar(1:2*N, 1:2*M) + sqrt(1 / (K + 1)) * H_tilde;
end

% Example usage:
% Parameters
% N = 4;          % Number of receive DP antennas
% M = 4;          % Number of transmit DP antennas
% K = 5;          % Ricean K-factor
% XPD = 10;       % Cross-Polarization Discrimination in dB
% ts = 0.5;       % Transmit spatial correlation coefficient
% rs = 0.75;      % Receive spatial correlation coefficient
% tp = 0.3;       % Transmit polarization correlation coefficient
% rp = 0.3;       % Receive polarization correlation coefficient
% 
% % Generate the channel
% H = generateDPChannel(N, M, K, XPD, ts, rs, tp, rp);
% 
% % Display the generated channel
% disp(H);
