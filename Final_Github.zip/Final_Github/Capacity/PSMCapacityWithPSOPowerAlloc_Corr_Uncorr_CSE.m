function PSMCapacityWithPSOPowerAlloc_Corr_Uncorr_CSE(Nt, Nr, M, swarmSize, maxIterations, SNR_Vector, numIterations, errorVariance)
    % Plot GSM Capacity with PSO-based Power Allocation considering Correlated and Uncorrelated Channels with CSE
    % Nt: Number of transmit antennas
    % Nr: Number of receive antennas
    % M: Modulation order
    % swarmSize: Size of the swarm in PSO
    % maxIterations: Maximum iterations for PSO
    % SNR_Vector: Vector of SNR values in dB
    % numIterations: Number of Monte Carlo iterations
    % errorVariance: Variance of channel state estimation errors

    capacityPSO_Correlated = zeros(size(SNR_Vector)); % Capacity for correlated channel
    capacityPSO_Uncorrelated = zeros(size(SNR_Vector)); % Capacity for uncorrelated channel
    capacityPSO_Correlated_CSE = zeros(size(SNR_Vector)); % Capacity for correlated channel with CSE
    capacityPSO_Uncorrelated_CSE = zeros(size(SNR_Vector)); % Capacity for uncorrelated channel with CSE

    % Channel parameters
    K = 0;  % Rician K-factor
    XPD = 5; % Cross-Polarization Discrimination factor in dB
    ts = 0.75; % Transmit spatial correlation coefficient
    rs = 0.75; % Receive spatial correlation coefficient
    tp = 0.3; % Transmit polarization correlation coefficient
    rp = 0.3; % Receive polarization correlation coefficient

    % Loop over each SNR value
    for snr_idx = 1:length(SNR_Vector)
        snrLinear = 10^(SNR_Vector(snr_idx)/10);

        % Accumulate capacity over multiple PSO runs for each channel type
        totalCapacityCorrelated = 0;
        totalCapacityUncorrelated = 0;
        totalCapacityCorrelated_CSE = 0;
        totalCapacityUncorrelated_CSE = 0;

        for itr = 1:numIterations
            % Correlated Channel with Perfect CSI
            [bestCapacityCorrelated, ~] = GSM_Capacity_PSO_PowerAlloc(Nt, Nr, M, swarmSize, maxIterations, snrLinear, 0, K, XPD, ts, rs, tp, rp, true);
            totalCapacityCorrelated = totalCapacityCorrelated + bestCapacityCorrelated;

            % Uncorrelated Channel with Perfect CSI
            [bestCapacityUncorrelated, ~] = GSM_Capacity_PSO_PowerAlloc(Nt, Nr, M, swarmSize, maxIterations, snrLinear, 0, K, XPD, ts, rs, tp, rp, false);
            totalCapacityUncorrelated = totalCapacityUncorrelated + bestCapacityUncorrelated;

            % Correlated Channel with CSE
            [bestCapacityCorrelated_CSE, ~] = GSM_Capacity_PSO_PowerAlloc(Nt, Nr, M, swarmSize, maxIterations, snrLinear, errorVariance, K, XPD, ts, rs, tp, rp, true);
            totalCapacityCorrelated_CSE = totalCapacityCorrelated_CSE + bestCapacityCorrelated_CSE;

            % Uncorrelated Channel with CSE
            [bestCapacityUncorrelated_CSE, ~] = GSM_Capacity_PSO_PowerAlloc(Nt, Nr, M, swarmSize, maxIterations, snrLinear, errorVariance, K, XPD, ts, rs, tp, rp, false);
            totalCapacityUncorrelated_CSE = totalCapacityUncorrelated_CSE + bestCapacityUncorrelated_CSE;
        end

        % Average capacity over the number of iterations
        capacityPSO_Correlated(snr_idx) = totalCapacityCorrelated / numIterations;
        capacityPSO_Uncorrelated(snr_idx) = totalCapacityUncorrelated / numIterations;
        capacityPSO_Correlated_CSE(snr_idx) = totalCapacityCorrelated_CSE / numIterations;
        capacityPSO_Uncorrelated_CSE(snr_idx) = totalCapacityUncorrelated_CSE / numIterations;
    end

    % Plot results
    figure;
    plot(SNR_Vector, capacityPSO_Correlated, '-o', 'DisplayName', 'PSO - Correlated Channel', 'LineWidth', 1.5);
    hold on;
    plot(SNR_Vector, capacityPSO_Uncorrelated, '-s', 'DisplayName', 'PSO - Uncorrelated Channel', 'LineWidth', 1.5);
    plot(SNR_Vector, capacityPSO_Correlated_CSE, '-x', 'DisplayName', 'PSO - Correlated Channel with CSE', 'LineWidth', 1.5);
    plot(SNR_Vector, capacityPSO_Uncorrelated_CSE, '-d', 'DisplayName', 'PSO - Uncorrelated Channel with CSE', 'LineWidth', 1.5);
    xlabel('SNR (dB)');
    ylabel('Capacity (bps/Hz)');
    title('GSM Capacity vs. SNR using PSO with Power Allocation and CSE Impact');
    legend show;
    grid on;
end

function [bestCapacity, bestConfig] = GSM_Capacity_PSO_PowerAlloc(Nt, Nr, M, swarmSize, maxIterations, snrLinear, errorVariance, K, XPD, ts, rs, tp, rp, isCorrelated)
    % PSO-based Power Allocation to Maximize GSM Capacity with Perfect and Imperfect CSI
    % fitnessFcn returns the negative of capacity to minimize in PSO optimization

    fitnessFcn = @(powerAlloc) -calculateCapacity(Nt, Nr, M, powerAlloc, snrLinear, errorVariance, K, XPD, ts, rs, tp, rp, isCorrelated);

    % Set options for PSO
    options = optimoptions('particleswarm', ...
        'SwarmSize', swarmSize, ...
        'MaxIterations', maxIterations, ...
        'Display', 'off', ...
        'UseParallel', false);

    % Bounds for power allocation per antenna
    lb = zeros(1, Nt);  % Lower bound for power allocation (no power)
    ub = ones(1, Nt);   % Upper bound for power allocation (maximum power per antenna)

    % Run PSO to find the best power allocation
    [bestConfig, bestCapacity] = particleswarm(fitnessFcn, Nt, lb, ub, options);

    % Invert the negative capacity to get the positive capacity
    bestCapacity = -bestCapacity;
end

function capacity = calculateCapacity(Nt, Nr, M, powerAlloc, snrLinear, errorVariance, K, XPD, ts, rs, tp, rp, isCorrelated)
    % Calculate capacity for the given power allocation considering perfect or imperfect CSI
    % Nt: Number of transmit antennas
    % Nr: Number of receive antennas
    % M: Modulation order
    % powerAlloc: Power allocation across antennas
    % snrLinear: SNR value in linear scale
    % errorVariance: Channel estimation error variance
    % isCorrelated: Boolean indicating whether the channel is correlated or uncorrelated

    % Normalize power allocation
    powerAlloc = powerAlloc / sum(powerAlloc);  % Ensure total power allocation sums to 1

    % Generate the MIMO channel based on correlation type
    if isCorrelated
        H = generateDPChannel(Nr, Nt, K, XPD, ts, rs, tp, rp); % Correlated channel
    else
        H = generateUncorrelatedDPChannel(Nr, Nt, K, XPD); % Uncorrelated channel
    end

    % Introduce channel estimation errors
    estimationError = sqrt(errorVariance) * (randn(2*Nr, 2*Nt) + 1j * randn(2*Nr, 2*Nt)) / sqrt(2);
    H_CSE = H + estimationError; % Channel with estimation error

    % Calculate the norm of the estimation error matrix
    error_norm = norm(estimationError, 'fro')^2; % Frobenius norm squared

    % Adjust the power allocation to match the size of H
    SNR_per_antenna = snrLinear * powerAlloc; % SNR scaled by power allocation
    SNR_matrix = diag(repmat(SNR_per_antenna, 1, 2)); % Extend to match 2N or 2M dimensions

    % Calculate the capacity using the Shannon formula
    capacity = log2(det(eye(size(H_CSE, 1)) + (H_CSE * SNR_matrix * H_CSE') / (error_norm + 1)));

    % Ensure capacity is real and positive
    capacity = max(real(capacity), 0); % Avoid negative capacities due to numerical issues
end

% Example usage:
%PSMCapacityWithPSOPowerAlloc_Corr_Uncorr_CSE(4, 4, 4, 20, 50, 0:5:40, 100, 0.01);
