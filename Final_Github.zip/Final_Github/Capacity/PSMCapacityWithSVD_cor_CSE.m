function PSMCapacityWithSVD_cor_CSE(Nt, Nr, M, SNR_dB, numIterations)
    % Nt: Number of transmit antennas
    % Nr: Number of receive antennas
    % M: Modulation order
    % SNR_dB: Range of SNR values in dB
    % numIterations: Number of Monte Carlo iterations

    % Convert SNR from dB to linear scale
    SNR_linear = 10.^(SNR_dB / 10);
    capacitySVD_Correlated = zeros(size(SNR_dB)); % Capacity array for correlated channel
    capacitySVD_Uncorrelated = zeros(size(SNR_dB)); % Capacity array for uncorrelated channel
    capacitySVD_Correlated_CSE = zeros(size(SNR_dB)); % Capacity array for correlated channel with CSE
    capacitySVD_Uncorrelated_CSE = zeros(size(SNR_dB)); % Capacity array for uncorrelated channel with CSE

    % Define channel parameters for correlated version
    K = 0;  % Rician K-factor
    XPD = 5; % Cross-Polarization Discrimination factor in dB
    ts = 0.77; % Transmit spatial correlation coefficient
    rs = 0.77; % Receive spatial correlation coefficient
    tp = 0.3; % Transmit polarization correlation coefficient
    rp = 0.3; % Receive polarization correlation coefficient
    error_variance = 0.01; % Channel estimation error variance

    % Loop over each SNR value
    for snr_idx = 1:length(SNR_dB)
        totalCapacityCorrelated = 0; % Accumulate capacity for correlated channel
        totalCapacityUncorrelated = 0; % Accumulate capacity for uncorrelated channel
        totalCapacityCorrelated_CSE = 0; % Accumulate capacity for correlated channel with CSE
        totalCapacityUncorrelated_CSE = 0; % Accumulate capacity for uncorrelated channel with CSE

        for itr = 1:numIterations
            % Generate Correlated and Uncorrelated MIMO channels
            H_correlated = generateDPChannel(Nt, Nr, K, XPD, ts, rs, tp, rp); % Correlated channel
            H_uncorrelated = generateUncorrelatedDPChannel(Nt, Nr, K, XPD); % Uncorrelated channel

            % Introduce channel estimation errors
            estimationError = sqrt(error_variance) * (randn(2*Nr, 2*Nt) + 1j * randn(2*Nr, 2*Nt)) / sqrt(2);
            H_correlated_CSE = H_correlated + estimationError; % Correlated channel with CSE
            H_uncorrelated_CSE = H_uncorrelated + estimationError; % Uncorrelated channel with CSE

            % Perform SVD on the correlated channel matrix
            [~, S_correlated, ~] = svd(H_correlated);
            [~, S_correlated_CSE, ~] = svd(H_correlated_CSE); % With estimation error

            % Perform SVD on the uncorrelated channel matrix
            [~, S_uncorrelated, ~] = svd(H_uncorrelated);
            [~, S_uncorrelated_CSE, ~] = svd(H_uncorrelated_CSE); % With estimation error

            % Extract the singular values (diagonal elements of S)
            singularValuesCorrelated = diag(S_correlated);
            singularValuesUncorrelated = diag(S_uncorrelated);
            singularValuesCorrelated_CSE = diag(S_correlated_CSE);
            singularValuesUncorrelated_CSE = diag(S_uncorrelated_CSE);

            % Calculate the norm of the estimation error matrix
            error_norm = norm(estimationError, 'fro')^2; % Frobenius norm squared

            % Power allocation with water-filling algorithm
            power_alloc_correlated = waterFilling(singularValuesCorrelated, SNR_linear(snr_idx));
            power_alloc_uncorrelated = waterFilling(singularValuesUncorrelated, SNR_linear(snr_idx));
            power_alloc_correlated_CSE = waterFilling(singularValuesCorrelated_CSE, SNR_linear(snr_idx) / (error_norm + 1));
            power_alloc_uncorrelated_CSE = waterFilling(singularValuesUncorrelated_CSE, SNR_linear(snr_idx) / (error_norm + 1));

            % Calculate the capacity using the SVD approach for correlated channel
            capacityCorrelated = sum(log2(1 + (Nt*power_alloc_correlated .* singularValuesCorrelated.^2)));

            % Calculate the capacity using the SVD approach for uncorrelated channel
            capacityUncorrelated = sum(log2(1 + (Nt*power_alloc_uncorrelated .* singularValuesUncorrelated.^2)));

            % Calculate the capacity using the SVD approach for correlated channel with CSE
            capacityCorrelated_CSE = sum(log2(1 + (Nt*power_alloc_correlated_CSE .* singularValuesCorrelated_CSE.^2) / (error_norm + 1)));

            % Calculate the capacity using the SVD approach for uncorrelated channel with CSE
            capacityUncorrelated_CSE = sum(log2(1 + (power_alloc_uncorrelated_CSE .* singularValuesUncorrelated_CSE.^2) / (error_norm + 1)));

            % Accumulate capacity
            totalCapacityCorrelated = totalCapacityCorrelated + capacityCorrelated;
            totalCapacityUncorrelated = totalCapacityUncorrelated + capacityUncorrelated;
            totalCapacityCorrelated_CSE = totalCapacityCorrelated_CSE + capacityCorrelated_CSE;
            totalCapacityUncorrelated_CSE = totalCapacityUncorrelated_CSE + capacityUncorrelated_CSE;
        end

        % Average capacity over the number of iterations
        capacitySVD_Correlated(snr_idx) = totalCapacityCorrelated / numIterations;
        capacitySVD_Uncorrelated(snr_idx) = totalCapacityUncorrelated / numIterations;
        capacitySVD_Correlated_CSE(snr_idx) = totalCapacityCorrelated_CSE / numIterations;
        capacitySVD_Uncorrelated_CSE(snr_idx) = totalCapacityUncorrelated_CSE / numIterations;
    end

    % Plot the capacity vs SNR
    figure;
    plot(SNR_dB, capacitySVD_Correlated, '-o', 'DisplayName', 'SVD - Correlated Channel');
    hold on;
    plot(SNR_dB, capacitySVD_Uncorrelated, '-s', 'DisplayName', 'SVD - Uncorrelated Channel');
    plot(SNR_dB, capacitySVD_Correlated_CSE, '-x', 'DisplayName', 'SVD - Correlated Channel with CSE');
    plot(SNR_dB, capacitySVD_Uncorrelated_CSE, '-d', 'DisplayName', 'SVD - Uncorrelated Channel with CSE');
    xlabel('SNR (dB)');
    ylabel('Capacity (bps/Hz)');
    title('GSM Capacity vs. SNR using SVD with Correlated and Uncorrelated Channels');
    legend('show');
    grid on;

    % Display the final capacity values
    disp('SVD-Based Capacity for Correlated Channel at different SNR values:');
    disp(capacitySVD_Correlated);

    disp('SVD-Based Capacity for Uncorrelated Channel at different SNR values:');
    disp(capacitySVD_Uncorrelated);

    disp('SVD-Based Capacity for Correlated Channel with CSE at different SNR values:');
    disp(capacitySVD_Correlated_CSE);

    disp('SVD-Based Capacity for Uncorrelated Channel with CSE at different SNR values:');
    disp(capacitySVD_Uncorrelated_CSE);
end

function power_alloc = waterFilling(singular_values, total_power)
    % Water-filling algorithm for power allocation
    % singular_values: Array of singular values (eigenmodes)
    % total_power: Total available power (in linear scale)

    num_modes = length(singular_values); % Number of modes (singular values)
    noise_power = 1; % Assume noise power is 1 for simplicity
    power_alloc = zeros(num_modes, 1); % Initialize power allocation vector

    % Compute inverse SNR for each mode
    inverse_snr = noise_power ./ singular_values.^2;

    % Iteratively adjust water level until the power constraint is met
    water_level = (total_power + sum(inverse_snr)) / num_modes;

    % Allocate power using water-filling principle
    for i = 1:num_modes
        power_alloc(i) = max(0, water_level - inverse_snr(i)); % Allocate power to each mode
    end
end

function H = generateDPChannel(N, M, K, XPD, ts, rs, tp, rp)
    % N: Number of receive antennas (DP)
    % M: Number of transmit antennas (DP)
    % K: Ricean K-factor
    % XPD: Cross-Polarization Discrimination factor (in dB)
    % ts, rs: Transmit and receive spatial correlation coefficients
    % tp, rp: Transmit and receive polarization correlation coefficients

    % Convert XPD from dB to linear scale
    alpha = 1 / (1 + 10^(XPD / 10));

    % Deterministic part (LoS component) H_bar
    H_bar = sqrt([1 - alpha, alpha; alpha, 1 - alpha]);
    H_bar = kron(eye(max(N, M)), H_bar); % Create a block diagonal matrix to scale appropriately

    % Correlation matrices
    C_tp = [1, tp; conj(tp), 1];
    C_rp = [1, rp; conj(rp), 1];
    C_ts = toeplitz([1, ts, zeros(1, N-2)]); % NxN spatial correlation matrix for receive antennas
    C_rs = toeplitz([1, rs, zeros(1, M-2)]); % MxM spatial correlation matrix for transmit antennas

    % Combined transmit and receive correlation matrices
    C_t = kron(C_ts, C_tp); % 2M x 2M transmit correlation matrix
    C_r = kron(C_rs, C_rp); % 2N x 2N receive correlation matrix

    % Generate the random fading matrix H_tilde (2N x 2M matrix)
    W = (randn(2*N, 2*M) + 1i * randn(2*N, 2*M)) / sqrt(2); % Random complex Gaussian entries
    H_tilde = (C_r^(1/2)) * W * (C_t^(1/2));

    % Combine deterministic and random parts to form H
    H = sqrt(K / (K + 1)) * H_bar(1:2*N, 1:2*M) + sqrt(1 / (K + 1)) * H_tilde;
end

function H = generateUncorrelatedDPChannel(N, M, K, XPD)
    % N: Number of receive antennas (DP)
    % M: Number of transmit antennas (DP)
    % K: Ricean K-factor
    % XPD: Cross-Polarization Discrimination factor (in dB)

    % Convert XPD from dB to linear scale
    alpha = 1 / (1 + 10^(XPD / 10));

    % Deterministic part (LoS component) H_bar
    H_bar = sqrt([1 - alpha, alpha; alpha, 1 - alpha]);
    H_bar = kron(eye(max(N, M)), H_bar); % Create a block diagonal matrix to scale appropriately
    H_bar = H_bar(1:2*N, 1:2*M); % Adjust size to match 2N x 2M

    % Generate the random fading matrix H_tilde with i.i.d entries (2N x 2M)
    H_tilde = (randn(2*N, 2*M) + 1i * randn(2*N, 2*M)) / sqrt(2); % 2N x 2M i.i.d complex Gaussian

    % Combine deterministic and random parts to form H
    H = sqrt(K / (K + 1)) * H_bar + sqrt(1 / (K + 1)) * H_tilde;
end

% Example usage:
%PSMCapacityWithSVD_cor_CSE(4, 4, 4, 0:5:40, 100);
